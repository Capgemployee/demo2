﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo2
{
    public class DaysofTheWeek
    {
        string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };

        public IEnumerable DisplayDays()
        {
            for (int i = 0; i < days.Length; i++)
            {
                yield return days[i];
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            DaysofTheWeek week = new DaysofTheWeek();

            foreach (string day in week.DisplayDays())
            {
                Console.WriteLine(day);
            }
        }
    }
}
