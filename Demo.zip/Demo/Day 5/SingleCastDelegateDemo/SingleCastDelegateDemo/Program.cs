﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleCastDelegateDemo
{
    public delegate string DelString(string str1, string str2, string str3);

    class Program
    {
        public string Concat(string str1, string str2, string str3)
        {
            return str1 + " " + str2 + " " + str3;
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            DelString del = new DelString(p.Concat);
            //string result = del("Hello", ".NET", "Batch");
            string result = del.Invoke("Hello", ".NET", "Batch");
            Console.WriteLine(result);
            //del = new DelString(String.Concat);
            Console.ReadKey();
        }
    }
}
