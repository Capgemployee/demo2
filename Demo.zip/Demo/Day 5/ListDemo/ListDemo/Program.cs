﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListDemo
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public double Salary { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<string> cityList = new List<string>();

            cityList.Add("Pune");
            cityList.Add("Mumbai");
            cityList.Add("Bangalore");
            cityList.Add("Chennai");
            cityList.Add("Hyderabad");
            cityList.Add("Noida");

            Console.WriteLine("City List : ");
            foreach (string item in cityList)
            {
                Console.WriteLine(item);
            }

            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() { EmployeeID = 101, EmployeeName = "Robert", Salary = 20000 });
            empList.Add(new Employee() { EmployeeID = 102, EmployeeName = "Sofia", Salary = 12334 });
            empList.Add(new Employee() { EmployeeID = 103, EmployeeName = "John", Salary = 23324 });
            empList.Add(new Employee() { EmployeeID = 104, EmployeeName = "Allister", Salary = 56789 });

            Console.WriteLine("\n\nEmployee List is :");
            foreach (Employee emp in empList)
            {
                Console.WriteLine("Employee ID : " + emp.EmployeeID + " Employee Name : " + emp.EmployeeName + " Salary : " + emp.Salary);
            }

            Console.ReadKey();
        }
    }
}
