﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type[] refTypes = refAssembly.GetTypes();

            Console.WriteLine("Total Number of Types in Assembly : " + refTypes.Length);
            for (int i = 0; i < refTypes.Length; i++)
            {
                Console.WriteLine("***********Name of the Type : " + refTypes[i].Name);
                Console.WriteLine("Assembly Qualified Name : " + refTypes[i].AssemblyQualifiedName);
                //Console.WriteLine("Base Type Name : " + refTypes[i].BaseType.Name);
                Console.WriteLine("Contains Generic Parameters : " + refTypes[i].ContainsGenericParameters);
                Console.WriteLine("Full Name : " + refTypes[i].FullName);
                Console.WriteLine("GUID : " + refTypes[i].GUID);
                Console.WriteLine("Has Element Type : " + refTypes[i].HasElementType);
                Console.WriteLine("Is Abstract : " + refTypes[i].IsAbstract);
                Console.WriteLine("Is Ansi Class : " + refTypes[i].IsAnsiClass);
                Console.WriteLine("Is Array : " + refTypes[i].IsArray);
                Console.WriteLine("Is Class : " + refTypes[i].IsClass);
                Console.WriteLine("Is Enum : " + refTypes[i].IsEnum);
                Console.WriteLine("Is Interface : " + refTypes[i].IsInterface);
                Console.WriteLine("Is Nested : " + refTypes[i].IsNested);
                Console.WriteLine("Is Public : " + refTypes[i].IsPublic);
                Console.WriteLine("Is Sealed : " + refTypes[i].IsSealed);
                Console.WriteLine("Is Serializable : " + refTypes[i].IsSerializable);
                Console.WriteLine("Is Value Type : " + refTypes[i].IsValueType);
                Console.WriteLine("Namespace : " + refTypes[i].Namespace);
                Console.WriteLine();
            }
        }
    }
}
