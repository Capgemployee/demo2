﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    public delegate void EventHandlerDelegate(string msg);

    public class EventPublisher
    {
        public event EventHandlerDelegate MyClickEvent;

        public void InvokeClickEvent(string msg)
        {
            if (MyClickEvent != null)
            {
                MyClickEvent(msg);
            }
            else
            {
                Console.WriteLine("There is not event handler available");
            }
        }
    }

    public class Subscriber
    {
        public void HandlerMethod(string msg)
        {
            Console.WriteLine(msg);
            Console.WriteLine("Event Occured");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            EventPublisher pub = new EventPublisher();
            Subscriber sub = new Subscriber();

            pub.MyClickEvent += sub.HandlerMethod;
            pub.InvokeClickEvent("Hi this is click event");

            Console.ReadKey();
        }
    }
}
