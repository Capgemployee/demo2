﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptionalNamedArgumentDemo
{
    class Program
    {
        public static void Addition(int num1=1, int num2=2, int num3=3)
        {
            Console.WriteLine("{0} + {1} + {2} => {3}", num1, num2, num3, (num1 + num2 + num3));
        }

        static void Main(string[] args)
        {
            //Optional Parameters
            Console.WriteLine("Output of Optional Parametes : ");
            Addition();
            Addition(100);
            Addition(100, 200);
            Addition(100, 200, 300);
            //Addition(100, , 300); Error : Argument Missing

            //Named Arguments
            Console.WriteLine("\n\nOutput of Named Argument : ");
            Addition(num1: 10, num2: 20, num3: 30);
            Addition(num2: 10, num3: 20, num1: 30);
            Addition(10, num3: 20, num2: 30);
            Addition(10, 20, num3: 30);
            //Addition(num1: 10, 20, num3: 30); Error : Named argument should be last
            //Addition(10, 20, num2: 30);
        }
    }
}
