﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jaggedArr = new int[5][];

            for (int i = 0; i < jaggedArr.GetLength(0); i++)
            {
                Console.Write("Enter Size of Array " + i + " : ");
                int size = Convert.ToInt32(Console.ReadLine());

                jaggedArr[i] = new int[size];
                Console.WriteLine("Enter Elements for array : " + i);
                for (int j = 0; j < jaggedArr[i].Length; j++)
                {
                    jaggedArr[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Jagged Array is : ");
            for (int i = 0; i < jaggedArr.GetLength(0); i++)
            {
                for (int j = 0; j < jaggedArr[i].Length; j++)
                {
                    Console.Write(jaggedArr[i][j] + "\t");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
