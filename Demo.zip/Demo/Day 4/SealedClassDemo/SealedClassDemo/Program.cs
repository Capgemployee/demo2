﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClassDemo
{
    public sealed class Circle
    { }

    public class Sphere : Circle   //Error : Sphere cannot derive sealed circle
    { }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
