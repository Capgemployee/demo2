﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceImplementation
{
    public class Employee : IMyInterface1, IMyInterface2
    {
        void IMyInterface1.Show()
        {
            Console.WriteLine("IMyInterface 1 Show method implemented in Employee");
        }

        void IMyInterface1.Display()
        {
            Console.WriteLine("IMyInterface 1 Display method implemented in Employee");
        }

        void IMyInterface2.Show()
        {
            Console.WriteLine("IMyInterface 2 Show method implemented in Employee");
        }

        void IMyInterface2.Print()
        {
            Console.WriteLine("IMyInterface 2 Print method implemented in Employee");
        }
    }
}
