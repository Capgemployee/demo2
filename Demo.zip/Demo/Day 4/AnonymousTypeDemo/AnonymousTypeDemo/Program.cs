﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var emp = new { EmployeeID = 101, Name = "Robert" };
            var emp1 = new { EmployeeID = 102, Name = "John" };
            var emp2 = new { Name = "Sofia", EmployeeID = 103 };
        }
    }
}
