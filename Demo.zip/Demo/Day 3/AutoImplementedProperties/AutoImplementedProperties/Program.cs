﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoImplementedProperties
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();

            Console.Write("Enter Employee ID : ");
            emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Employee Name : ");
            emp.EmployeeName = Console.ReadLine();
            Console.Write("Enter Salry : ");
            emp.Salary = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Date of Birth : ");
            emp.DOB = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("\nEmployee ID is : " + emp.EmployeeID);
            Console.WriteLine("Employee Name is : " + emp.EmployeeName);
            Console.WriteLine("Employee Salary is : " + emp.Salary);
            Console.WriteLine("Employee Date of Birth is : " + emp.DOB);

            Console.ReadKey();
        }
    }
}
