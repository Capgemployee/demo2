﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorinInheritance
{
    public class Manager : Employee
    {
        public Manager() : base()
        {
            Console.WriteLine("Manager Class Default Constructor");
        }

        public Manager(int empid, string name, double allowance) : base(empid, name)
        {
            Console.WriteLine("Manager Class Parameterized Constructor");
        }
    }
}
