﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo2
{
    public class Employee
    {
        int empId;
        string empName;
        double salary;

        public Employee()
        {
            empId = 1;
            empName = "ABC";
            salary = 12000.49000;
        }

        public Employee(int empId, string empName, double salary)
        {
            this.empId = empId;
            this.empName = empName;
            this.salary = salary;
        }

        public void Print()
        {
            Console.WriteLine("Employee ID is : " + empId);
            Console.WriteLine("Employee Name is : " + empName);
            Console.WriteLine("Employee Salary is : " + salary);
        }
    }
}
