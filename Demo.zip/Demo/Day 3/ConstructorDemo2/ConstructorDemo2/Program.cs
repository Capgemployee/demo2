﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Employee ID : ");
            int empID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Employee Name : ");
            string empName = Console.ReadLine();

            Console.Write("Enter Salary : ");
            double salary = Convert.ToDouble(Console.ReadLine());

            Employee emp = new Employee(empID, empName, salary);

            emp.Print();

            Employee emp1 = new Employee();
            Console.ReadKey();
        }
    }
}
